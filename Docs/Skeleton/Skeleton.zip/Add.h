//
// Created by Admin on 2023. 05. 06..
//

#ifndef NHF_SPORTEGYESULET_ADD_H
#define NHF_SPORTEGYESULET_ADD_H

#include <iostream>
#include <map>
#include <functional>
#include "../Data/string.h"

inline void Addfootballteam();
inline void Addbasketballteam();
inline void Addhandballteam();
inline void Addmenu();


#endif //NHF_SPORTEGYESULET_ADD_H
