//
// Created by Admin on 2023. 05. 06..
//

#ifndef NHF_SPORTEGYESULET_LISTS_H
#define NHF_SPORTEGYESULET_LISTS_H

#include <iostream>
#include <map>
#include <functional>
#include "../Data/string.h"
#include "Teamlists.h"

inline void Sponsorlist();
inline void SponsorSupporlist();
inline void Supportlist();
inline void Listsmenu();


#endif //NHF_SPORTEGYESULET_LISTS_H
