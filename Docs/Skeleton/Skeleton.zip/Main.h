//
// Created by Admin on 2023. 05. 06..
//

#ifndef NHF_SPORTEGYESULET_MAIN_H
#define NHF_SPORTEGYESULET_MAIN_H

#include <iostream>
#include <map>
#include <functional>
#include "../Data/string.h"
#include "Add.h"
#include "Manageteams.h"
#include "Lists.h"

inline void BaseData();

inline void Mainmenu();


#endif //NHF_SPORTEGYESULET_MAIN_H
