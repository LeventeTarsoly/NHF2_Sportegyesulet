//
// Created by Admin on 2023. 05. 06..
//

#ifndef NHF_SPORTEGYESULET_TEAMS_H
#define NHF_SPORTEGYESULET_TEAMS_H


#include <iostream>
#include <map>
#include <functional>
#include "../Data/string.h"
#include "Add.h"

inline void Modifyteam();
inline void Deleteteam();
inline void Manageteamsmenu();


#endif //NHF_SPORTEGYESULET_TEAMS_H
