//
// Created by Admin on 2023. 05. 06..
//

#ifndef NHF_SPORTEGYESULET_TEAMLISTS_H
#define NHF_SPORTEGYESULET_TEAMLISTS_H

#include <iostream>
#include <map>
#include <functional>
#include "../Data/string.h"

using namespace std;
inline void Footballlist();
inline void Basketballlist();
inline void Handballlist();
inline void Teamlistsmenu();

#endif //NHF_SPORTEGYESULET_TEAMLISTS_H
