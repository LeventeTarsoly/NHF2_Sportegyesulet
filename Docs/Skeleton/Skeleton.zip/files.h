//
// Created by TLevente on 16/05/2023.
//

#ifndef NHF_SPORTEGYESULET_FILES_H
#define NHF_SPORTEGYESULET_FILES_H
//TODO
void Read(){}
//TODO
void Save(){}


#endif //NHF_SPORTEGYESULET_FILES_H
