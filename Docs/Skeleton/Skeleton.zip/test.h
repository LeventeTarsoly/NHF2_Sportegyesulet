//TODO Test if the files could be opened and read
bool filetest(){}

//TODO Test if the derived classes can be construsted and stored in the heterogenous collection
bool classtest();

//TODO Test of the functions in the classes
bool functiontest(){}